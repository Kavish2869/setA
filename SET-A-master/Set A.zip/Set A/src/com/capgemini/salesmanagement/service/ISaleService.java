package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleService {
	public HashMap<Integer,Sale> insertSaleDetails(Sale sale);
	public boolean validateProductCode(int productId);
	public boolean validateProductCategory(String prodCat);
	public boolean validateProductName(String prodName);
	public boolean validateProductPrice(float price);
}
