package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ISaleService service = new SaleService();
		System.out.print("Enter the Product Code");
		int productCode = sc.nextInt();
		System.out.println("Enter the quantity");
		int productQuantity=sc.nextInt();
		System.out.println("Product category");
		String productCategory=sc.next();
		System.out.println("Product name");
		String productName=sc.next();
		System.out.println("Product description");
		String productDescription=sc.next();
		System.out.println("Product price");
		int productPrice=sc.nextInt();
		LocalDate date = LocalDate.now();
		Sale sale = new Sale(productCode,productQuantity,productCategory,productName,productDescription,productPrice,date);
		System.out.println(service.insertSaleDetails(sale));
		//System.out.println(sale);
		
	}
}
